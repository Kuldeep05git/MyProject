﻿using OnlineShoppingStore.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OnlineShoppingStore.Domain.Abstract
{
    public class IProductRepository
    {
        public IEnumerable<Product> Products { get; }
    }
}
